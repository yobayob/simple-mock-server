$(document).ready(function() {
    $('.selectize').selectize({});
});